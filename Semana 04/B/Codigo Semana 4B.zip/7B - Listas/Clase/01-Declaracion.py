lista1 = []  #len = 0
lista2 = [None] #len = 1

enteros = [0,1,2,3,4,5,6,7,8,9]
dias = ["Lunes","Martes","Miercoles","Jueves","Viernes","Sabado","Domingo"]
variados = [1,"Martes",3,"Jueves",5,"Sabado",7,7.12]


# print(lista1)
# print(lista2)
# print(enteros)
# print(dias)
# print(variados)


# len o tamaño
print(len(lista1))
print(len(lista2))
