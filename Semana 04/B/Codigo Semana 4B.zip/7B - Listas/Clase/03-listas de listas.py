lista1 = [1,2,3,["Lunes","Martes","Miercoles"],[4,5,6]]
lista2 = [["utopia","mediatica"],["IQ",135]]


# print(lista1)
print(lista2)
# print(len(lista1))
# print(len(lista2))

# print(lista1[4][1])
print(lista2[0][1],lista2[1][1])