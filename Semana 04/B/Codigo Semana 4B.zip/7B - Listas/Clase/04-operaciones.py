#IN
# lista = ["Juan", "Luis", "Almendra", "Jorlan", "Maria", "Luisa"]
# print("Juan" in lista)
# print("juan" in lista)
# print("Pedro" in lista)

#NOT IN

lista = ["Juan", "Luis", "Almendra", "Jorlan", "Maria", "Luisa"]
print("Juan" not in lista)
print("Pedro" not in lista)
