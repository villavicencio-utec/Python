lista = ["Juan", "Luis", "Almendra", "Jorlan", "Maria", "Luisa"]

# nom1, nom2, nom3, nom4, nom5, nom6 = lista
# nom1, nom2, nom3, nom4 = lista
nom1, nom2, nom3, nom4, nom5, nom6, nom7, nom8 = lista
print(nom1)
print(nom2)
print(nom3)
print(nom4)
# print(nom5)
# print(nom6)


