lista = [1,2,3,4,5,6,7,8,9,0]
# listapunteros = lista[:]
listapunteros = lista.copy()
print(listapunteros)
lista[2]=200
lista[4]=400
print(listapunteros)