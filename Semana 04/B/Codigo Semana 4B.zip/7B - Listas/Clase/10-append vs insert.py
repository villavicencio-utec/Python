# lista_letras = ['a', 'b', 'c', 'd', 'e']
# print(lista_letras)
# lista_letras.append('f')
# lista_letras.append('g')
# lista_letras.append('h')
# print(lista_letras)


lista_letras = ['a', 'b', 'c', 'd', 'e']  # 0 - 4
# print(lista_letras)
# lista_letras.insert(0, 'A')
# lista_letras.insert(2, 'B')
# lista_letras.insert(4, 'C')
# print(lista_letras)

# Casos especiales.
lista_letras.insert(50, 'Z')
lista_letras.insert(-2, 'K')
print(lista_letras)
