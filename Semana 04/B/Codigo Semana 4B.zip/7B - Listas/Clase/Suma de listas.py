padres = ["mama", "papa"]
abuelos = ["abuelo", "abuela", "hijos"]
familia_1 = padres + abuelos + padres
familia_2 = abuelos + padres
print(familia_1)
print(familia_2)
