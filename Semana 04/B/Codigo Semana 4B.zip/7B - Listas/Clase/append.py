

lista = [1, 2, 3]
print("Antes de append", lista)
lista.append("NUEVO")
print("Luego de append", lista)


x = ["Salon 1", "Salon 2", "Salon 3"]
lista.append(x)
print("Luego de append de una lista", lista)
print(len(lista))

