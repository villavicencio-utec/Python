# del Si se necesita eliminar una porción de la lista, se utiliza la función del.
print("Ejemplos con DEL")
lista_letras = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l']
print(lista_letras)
# del lista_letras[3]
# print(lista_letras)
# del lista_letras[:4]
# print(lista_letras)
del lista_letras
print(lista_letras)  # Error porque la variable ya no existe.