from random import randint

x = randint(1, 10)
print(x)
