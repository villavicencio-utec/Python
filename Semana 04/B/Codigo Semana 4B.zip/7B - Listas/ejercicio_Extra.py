#1
# Sin crear una lista adicional, elimine todos los elementos duplicados de una lista.
# 	input: [5, 8, 4, 7, 6, 2, 1, 9, 8, 4, 3, 2, 8]
# 	output: [5, 8, 4, 7, 6, 2, 1, 9, 3]

#2
# Un tablero de ajedrez puede ser representado por una matriz de 8 x 8.
# Asuma que el tablero esta vacío (lleno de 0s). Posteriormente,
# solicite una posición inicial en el tablero. Finalmente, simule a que posiciones (marcando con un 1)
# se podría mover desde esa posición: una torre (a), un alfil (b) y una reina (c.).
# Se sugiere implementar una función para cada pieza.

